module.exports = {
  rpc: {
    host: 'localhost',
    port: 8545,
    gas: 1900000
  },
  // networks: {
  //   development: {
  //     host: "localhost",
  //     port: 8545,
  //     network_id: "*" // Match any network id
  //   }
  // },
  migrations_directory: './migrations'
}
